require 'quanto/records/biosample'
require 'quanto/records/summary-merge'
require 'quanto/records/summary'
require 'quanto/records/fastqc'
require 'quanto/records/sra'
require 'quanto/records/io'
require 'quanto/records'
require 'xml_parser'

module Quanto
	# something goes here
end
